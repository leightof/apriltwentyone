function setup() {
  createCanvas(500, 500);
}

function draw() {
  background(32);

  // Draw grid.
  push();
  stroke(64);
  for (x = 50; x < width; x += 50) {
    line(x, 0, x, height);
  }

  for (y = 50; y < height; y += 50) {
    line(0, y, width, y);
  }
  pop();

  // Show collected points.
  
  // Show current position.
  push();
  fill(255, 255, 0);
  text("(" + mouseX + ", " + mouseY + ")", mouseX+15, mouseY+25);
  pop();
}
